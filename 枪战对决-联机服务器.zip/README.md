# 枪战对决 · 联机中继服务

只负责「配对」和「转发」，不跑游戏逻辑，所以一台最小的免费实例就够。

## 部署到 Render（免费，无需信用卡）

1. 注册 GitHub（没有的话，邮箱就能注册）。
2. 新建一个仓库（public 或 private 都行），把**本目录的 3 个文件**传上去：
   - `index.js`
   - `package.json`
   - `README.md`（可选）
3. 打开 https://dashboard.render.com → **New +** → **Web Service**。
4. 连你的 GitHub 仓库，然后按下表填写：

   | 字段 | 值 |
   |---|---|
   | Language / Runtime | Node |
   | Build Command | `npm install` |
   | Start Command | `npm start` |
   | Instance Type | Free |

5. 点 Create Web Service，等 1~2 分钟变成 **Live**。
6. 页面顶部会给你一个地址，形如 `https://gunfight-relay-xxxx.onrender.com`。
   **把它开头的 `https` 改成 `wss`**，得到：
   ```
   wss://gunfight-relay-xxxx.onrender.com
   ```
7. 打开游戏 → 设置 → **联机服务器**，把这一串粘进去 → 保存。
8. 主菜单点「联机对战」→ 创建房间 → 把 5 位房间码发给朋友。

## 注意

- **免费实例会休眠**：连续 15 分钟没人访问会睡，下次连要等 30~60 秒唤醒。开局前先让对方点一次，等连上再建房。
- 服务端在 Render 美国节点，国内延迟大约 150~300ms，休闲对枪够用，别指望电竞级。
- 房间码 5 位，去掉易混淆的 I/O/0/1；房间满 2 人；房主退出房间即销毁；空房 30 分钟自动回收。
- 服务端只转发 `state / shot / dmg / died / start / leave` 这些消息，不做任何校验以外的操作。

## 本地调试

```bash
npm install
PORT=8099 node index.js
# 健康检查
curl http://127.0.0.1:8099/health
```
